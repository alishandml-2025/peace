// ================================================================
// SPLASH SCREEN WITH VIDEO
// ================================================================
let splashTimer = null;

function startSplashCountdown() {
    // Auto-dismiss after video plays for 4 seconds
    splashTimer = setTimeout(function() {
        dismissSplash();
    }, 4000);
}

function dismissSplash() {
    const splash = document.getElementById('splash-screen');
    splash.classList.add('fade-out');
    setTimeout(function() {
        splash.style.display = 'none';
    }, 800);
}

function skipSplash() {
    if (splashTimer) clearTimeout(splashTimer);
    dismissSplash();
}

window.addEventListener('load', startSplashCountdown);

// ================================================================
// SCROLL TO NEXT SECTION
// ================================================================
function scrollToNextSection() {
    const homeSection = document.getElementById('home');
    const nextSection = homeSection.nextElementSibling;
    
    if (nextSection) {
        nextSection.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    }
}

// ================================================================
// GO TO HOME FUNCTION (for logo click)
// ================================================================
function goToHome() {
    showPage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ================================================================
// NAVIGATION — Page switching and active state management
// ================================================================

function showPage(pageId) {
    const sections = document.querySelectorAll('.page-section');
    sections.forEach(function(section) {
        section.classList.remove('active-section');
    });

    const target = document.getElementById(pageId);
    if (target) {
        target.classList.add('active-section');
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function(link) {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === pageId) {
            link.classList.add('active');
        }
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });

    const nav = document.getElementById('main-nav');
    nav.classList.remove('mobile-open');
}

function toggleMobileMenu() {
    const nav = document.getElementById('main-nav');
    nav.classList.toggle('mobile-open');
}

// ================================================================
// GO TO TOP BUTTON
// ================================================================
window.addEventListener('scroll', function() {
    const goToTop = document.getElementById('goToTop');
    if (window.scrollY > 300) {
        goToTop.classList.add('show');
    } else {
        goToTop.classList.remove('show');
    }
});

// ================================================================
// GALLERY
// ================================================================

const galleryData = [
    {
        src: 'https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=800&q=80',
        alt: 'Hands joined together representing unity and solidarity for peace',
        title: 'Unity for Peace',
        desc: 'Around the world, people are joining hands to create communities built on mutual respect, understanding, and cooperation.'
    },
    {
        src: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&q=80',
        alt: 'Legal documents on a desk symbolising access to fair legal systems for everyone',
        title: 'Justice for All',
        desc: 'Fair and accessible legal systems are a cornerstone of SDG 16. Every person deserves equal protection under the law.'
    },
    {
        src: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800&q=80',
        alt: 'Group of professionals in a meeting promoting transparent decision-making and governance',
        title: 'Transparent Governance',
        desc: 'Accountable institutions build public trust. When government decisions are made openly, everyone benefits.'
    },
    {
        src: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?w=800&q=80',
        alt: 'People in a community discussion circle promoting dialogue and conflict resolution',
        title: 'Community Dialogue',
        desc: 'Open dialogue is the first step toward resolving conflicts peacefully. Conversation is more powerful than confrontation.'
    },
    {
        src: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=800&q=80',
        alt: 'Young volunteers working together at a community service project for social justice',
        title: 'Youth Leading Change',
        desc: 'Young people are not just the leaders of tomorrow — they are change-makers today.'
    },
    {
        src: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=800&q=80',
        alt: 'Open lock symbolising freedom of information and anti-corruption transparency measures',
        title: 'Fighting Corruption',
        desc: 'Corruption undermines public trust. Anti-corruption campaigns are essential for building strong institutions.'
    }
];

function populateGallery() {
    const grid = document.getElementById('gallery-grid');
    galleryData.forEach(function(item, index) {
        const thumb = document.createElement('div');
        thumb.className = 'gallery-thumb';
        thumb.setAttribute('tabindex', '0');
        thumb.setAttribute('role', 'button');
        thumb.setAttribute('aria-label', 'View details: ' + item.title);

        thumb.innerHTML = '<img src="' + item.src + '" alt="' + item.alt + '">' +
            '<div class="thumb-label">' + item.title + '</div>';

        thumb.addEventListener('click', function() {
            openGalleryModal(index);
        });

        thumb.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openGalleryModal(index);
            }
        });

        grid.appendChild(thumb);
    });
}

function openGalleryModal(index) {
    const item = galleryData[index];
    const modal = document.getElementById('gallery-modal');
    document.getElementById('modal-img').src = item.src;
    document.getElementById('modal-img').alt = item.alt;
    document.getElementById('modal-title').textContent = item.title;
    document.getElementById('modal-desc').textContent = item.desc;
    modal.classList.add('open');
    changeModalTheme('light');
    changeModalFont('sans');
}

function closeGalleryModal() {
    document.getElementById('gallery-modal').classList.remove('open');
}

document.getElementById('gallery-modal').addEventListener('click', function(e) {
    if (e.target === this) closeGalleryModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeGalleryModal();
});

function changeModalTheme(theme) {
    const body = document.getElementById('modal-body');
    const content = document.getElementById('modal-content');
    if (theme === 'dark') {
        content.style.background = '#1a1a2e';
        body.style.color = '#e0e0e0';
    } else if (theme === 'sepia') {
        content.style.background = '#f5e6c8';
        body.style.color = '#5d4037';
    } else {
        content.style.background = 'white';
        body.style.color = '#333';
    }
}

function changeModalFont(font) {
    const body = document.getElementById('modal-body');
    if (font === 'serif') {
        body.style.fontFamily = 'Georgia, "Times New Roman", serif';
    } else if (font === 'mono') {
        body.style.fontFamily = '"Courier New", Courier, monospace';
    } else {
        body.style.fontFamily = '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif';
    }
}

populateGallery();

// ================================================================
// ACTION IMPACT SIMULATOR
// ================================================================

const aisActions = [
    { title: 'Organise a Peace Workshop', desc: 'Host a campus workshop on conflict resolution.', points: 5, img: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=200&q=80', alt: 'Peace workshop' },
    { title: 'Report Corruption', desc: 'Use official channels to report unethical behaviour.', points: 4, img: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=200&q=80', alt: 'Reporting corruption' },
    { title: 'Volunteer at Legal Aid', desc: 'Donate your time to help a free legal aid clinic.', points: 5, img: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=200&q=80', alt: 'Legal aid' },
    { title: 'Join Student Government', desc: 'Participate in student union elections.', points: 3, img: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=200&q=80', alt: 'Student government' },
    { title: 'Share Rights Awareness', desc: 'Create social media content educating others.', points: 2, img: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=200&q=80', alt: 'Social media' },
    { title: 'Attend a Council Meeting', desc: 'Visit a local government meeting.', points: 3, img: 'https://images.unsplash.com/photo-1577415124269-fc1140815997?w=200&q=80', alt: 'Council meeting' },
    { title: 'Mentor a Younger Student', desc: 'Guide a younger student on conflict resolution.', points: 4, img: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=200&q=80', alt: 'Mentoring' },
    { title: 'Support Anti-Bullying', desc: 'Champion anti-bullying policies.', points: 3, img: 'https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=200&q=80', alt: 'Anti-bullying' }
];

let selectedActions = new Set();

function populateAIS() {
    const container = document.getElementById('action-cards');
    aisActions.forEach(function(action, index) {
        const card = document.createElement('div');
        card.className = 'action-card';
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'checkbox');
        card.setAttribute('aria-checked', 'false');
        card.setAttribute('data-index', index);

        card.innerHTML =
            '<img src="' + action.img + '" alt="' + action.alt + '">' +
            '<div class="action-info">' +
                '<h4>' + action.title + '</h4>' +
                '<p>' + action.desc + '</p>' +
                '<span class="impact-badge">+' + action.points + ' pts</span>' +
            '</div>';

        card.addEventListener('click', function() {
            toggleAction(index, this);
        });

        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleAction(index, this);
            }
        });

        container.appendChild(card);
    });
}

function toggleAction(index, cardEl) {
    if (selectedActions.has(index)) {
        selectedActions.delete(index);
        cardEl.classList.remove('selected');
        cardEl.setAttribute('aria-checked', 'false');
    } else {
        selectedActions.add(index);
        cardEl.classList.add('selected');
        cardEl.setAttribute('aria-checked', 'true');
    }
    updateImpactScore();
}

function updateImpactScore() {
    let total = 0;
    selectedActions.forEach(function(index) {
        total += aisActions[index].points;
    });

    const maxPossible = aisActions.reduce(function(sum, a) { return sum + a.points; }, 0);

    document.getElementById('impact-score').textContent = total;

    const percentage = Math.min((total / maxPossible) * 100, 100);
    const bar = document.getElementById('impact-bar-fill');
    bar.style.width = percentage + '%';

    const levelEl = document.getElementById('impact-level');
    const messageEl = document.getElementById('impact-message');
    const aisContainer = document.getElementById('ais-container');

    if (total === 0) {
        levelEl.textContent = 'Select actions below to begin!';
        levelEl.style.color = '#888';
        messageEl.textContent = '';
        bar.style.background = '#e0e0e0';
        aisContainer.style.backgroundImage = 'none';
    } else if (total <= 8) {
        levelEl.textContent = '🌱 Low Impact';
        levelEl.style.color = '#e67e22';
        messageEl.textContent = 'Every journey begins with a single step. Keep selecting actions to grow your impact!';
        bar.style.background = 'linear-gradient(90deg, #e67e22, #f39c12)';
        aisContainer.style.backgroundImage = 'url("https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&q=60")';
    } else if (total <= 18) {
        levelEl.textContent = '🌿 Medium Impact';
        levelEl.style.color = '#2980b9';
        messageEl.textContent = 'Great progress! You are making a meaningful difference in your community.';
        bar.style.background = 'linear-gradient(90deg, #2980b9, #3498db)';
        aisContainer.style.backgroundImage = 'url("https://images.unsplash.com/photo-1501854140801-50d01698950b?w=1200&q=60")';
    } else {
        levelEl.textContent = '🌳 High Impact — Champion!';
        levelEl.style.color = '#27ae60';
        messageEl.textContent = 'Outstanding! You are a true champion of peace, justice, and strong institutions!';
        bar.style.background = 'linear-gradient(90deg, #27ae60, #2ecc71)';
        aisContainer.style.backgroundImage = 'url("https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1200&q=60")';
    }
}

populateAIS();

// ================================================================
// FEEDBACK FORM
// ================================================================

document.getElementById('fb-message').addEventListener('input', function() {
    const maxLen = parseInt(this.getAttribute('maxlength'));
    const current = this.value.length;
    document.getElementById('char-counter').textContent = current + ' / ' + maxLen;
    const counter = document.getElementById('char-counter');
    if (current > maxLen * 0.9) {
        counter.style.color = 'var(--danger)';
    } else {
        counter.style.color = '#888';
    }
});

function handleFeedbackSubmit(e) {
    e.preventDefault();

    let isValid = true;

    document.querySelectorAll('.form-group').forEach(function(group) {
        group.classList.remove('has-error');
    });

    const nameField = document.getElementById('fb-name');
    if (!nameField.value.trim()) {
        nameField.closest('.form-group').classList.add('has-error');
        isValid = false;
    }

    const emailField = document.getElementById('fb-email');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailField.value.trim() || !emailRegex.test(emailField.value)) {
        emailField.closest('.form-group').classList.add('has-error');
        isValid = false;
    }

    const messageField = document.getElementById('fb-message');
    if (!messageField.value.trim() || messageField.value.trim().length < 10) {
        messageField.closest('.form-group').classList.add('has-error');
        isValid = false;
    }

    if (isValid) {
        document.getElementById('feedback-form').style.display = 'none';
        document.getElementById('feedback-confirmation').style.display = 'block';
    }

    return false;
}

// ================================================================
// USER PROFILE
// ================================================================

let profileData = {
    step1: { completed: false, name: '', username: '', role: '' },
    step2: { completed: false, interest1: '', interest2: '', interest3: '' },
    step3: { completed: false, goal1: '', goal2: '', goal3: '' }
};

function startProfileStep(step) {
    if (step === 1) {
        const name = prompt('Step 1 of 3 — Basic Details\n\nWhat is your full name? (Press Cancel to skip)');
        const username = prompt('Choose a username for your peace profile: (Press Cancel to skip)');
        const role = prompt('What is your role? (e.g. Student, Volunteer, Activist)\n(Press Cancel to skip)');

        profileData.step1 = {
            completed: true,
            name: name || '',
            username: username || '',
            role: role || ''
        };
        renderProfileStep1();
    } else if (step === 2) {
        const interest1 = prompt('Step 2 of 3 — Interests & Preferences\n\nWhat area of SDG 16 interests you most?\n(e.g. Peace, Justice, Anti-Corruption)\n(Press Cancel to skip)');
        const interest2 = prompt('What is your preferred way to take action?\n(e.g. Volunteering, Social Media, Policy Advocacy)\n(Press Cancel to skip)');
        const interest3 = prompt('Which community are you most passionate about helping?\n(Press Cancel to skip)');

        profileData.step2 = {
            completed: true,
            interest1: interest1 || '',
            interest2: interest2 || '',
            interest3: interest3 || ''
        };
        renderProfileStep2();
    } else if (step === 3) {
        const goal1 = prompt('Step 3 of 3 — Commitments & Goals\n\nWhat is one action you commit to taking this month for peace?\n(Press Cancel to skip)');
        const goal2 = prompt('What change would you like to see in your community within a year?\n(Press Cancel to skip)');
        const goal3 = prompt('What is your long-term vision for a just society?\n(Press Cancel to skip)');

        profileData.step3 = {
            completed: true,
            goal1: goal1 || '',
            goal2: goal2 || '',
            goal3: goal3 || ''
        };
        renderProfileStep3();
    }

    updateProfileProgress();
}

function renderProfileStep1() {
    const output = document.getElementById('step1-output');
    const section = document.getElementById('profile-step1');
    const data = profileData.step1;
    let html = '';

    if (data.name) html += '<p style="margin-bottom:0.4rem;"><strong>Name:</strong> ' + escapeHtml(data.name) + '</p>';
    if (data.username) html += '<p style="margin-bottom:0.4rem;"><strong>Username:</strong> @' + escapeHtml(data.username) + '</p>';
    if (data.role) html += '<p style="margin-bottom:0.4rem;"><strong>Role:</strong> ' + escapeHtml(data.role) + '</p>';

    if (html) {
        output.innerHTML = html;
        section.classList.add('visible');
        document.getElementById('profile-empty').style.display = 'none';
    }

    document.getElementById('step1-btn').textContent = '✅ Step 1: Completed (Redo)';
    document.getElementById('step1-btn').className = 'btn btn-secondary';
}

function renderProfileStep2() {
    const output = document.getElementById('step2-output');
    const section = document.getElementById('profile-step2');
    const data = profileData.step2;
    let html = '';

    if (data.interest1) html += '<p style="margin-bottom:0.4rem;"><strong>Key Interest:</strong> ' + escapeHtml(data.interest1) + '</p>';
    if (data.interest2) html += '<p style="margin-bottom:0.4rem;"><strong>Preferred Action:</strong> ' + escapeHtml(data.interest2) + '</p>';
    if (data.interest3) html += '<p style="margin-bottom:0.4rem;"><strong>Target Community:</strong> ' + escapeHtml(data.interest3) + '</p>';

    if (html) {
        output.innerHTML = html;
        section.classList.add('visible');
        document.getElementById('profile-empty').style.display = 'none';
    }

    document.getElementById('step2-btn').textContent = '✅ Step 2: Completed (Redo)';
    document.getElementById('step2-btn').className = 'btn btn-secondary';
}

function renderProfileStep3() {
    const output = document.getElementById('step3-output');
    const section = document.getElementById('profile-step3');
    const data = profileData.step3;
    let html = '';

    if (data.goal1) html += '<p style="margin-bottom:0.4rem;"><strong>Monthly Action:</strong> ' + escapeHtml(data.goal1) + '</p>';
    if (data.goal2) html += '<p style="margin-bottom:0.4rem;"><strong>1-Year Vision:</strong> ' + escapeHtml(data.goal2) + '</p>';
    if (data.goal3) html += '<p style="margin-bottom:0.4rem;"><strong>Long-term Vision:</strong> ' + escapeHtml(data.goal3) + '</p>';

    if (html) {
        output.innerHTML = html;
        section.classList.add('visible');
        document.getElementById('profile-empty').style.display = 'none';
    }

    document.getElementById('step3-btn').textContent = '✅ Step 3: Completed (Redo)';
    document.getElementById('step3-btn').className = 'btn btn-secondary';
}

function updateProfileProgress() {
    let filledPrompts = 0;
    const totalPrompts = 9;

    if (profileData.step1.name) filledPrompts++;
    if (profileData.step1.username) filledPrompts++;
    if (profileData.step1.role) filledPrompts++;
    if (profileData.step2.interest1) filledPrompts++;
    if (profileData.step2.interest2) filledPrompts++;
    if (profileData.step2.interest3) filledPrompts++;
    if (profileData.step3.goal1) filledPrompts++;
    if (profileData.step3.goal2) filledPrompts++;
    if (profileData.step3.goal3) filledPrompts++;

    const percentage = Math.round((filledPrompts / totalPrompts) * 100);
    document.getElementById('profile-progress-bar').style.width = percentage + '%';
    document.getElementById('progress-text').textContent = percentage + '%';

    let stepsCompleted = 0;
    if (profileData.step1.completed) stepsCompleted++;
    if (profileData.step2.completed) stepsCompleted++;
    if (profileData.step3.completed) stepsCompleted++;

    document.getElementById('step-counter').textContent = 'Step ' + stepsCompleted + ' of 3 completed | ' + filledPrompts + '/' + totalPrompts + ' fields filled';
    document.getElementById('reset-profile-btn').style.display = stepsCompleted > 0 ? 'inline-block' : 'none';
}

function resetProfile() {
    if (!confirm('Are you sure you want to reset your profile?')) return;

    profileData = {
        step1: { completed: false, name: '', username: '', role: '' },
        step2: { completed: false, interest1: '', interest2: '', interest3: '' },
        step3: { completed: false, goal1: '', goal2: '', goal3: '' }
    };

    document.querySelectorAll('.profile-section').forEach(function(s) {
        s.classList.remove('visible');
    });

    document.getElementById('profile-empty').style.display = 'block';

    document.getElementById('step1-btn').textContent = 'Step 1: Basic Details';
    document.getElementById('step1-btn').className = 'btn btn-primary';
    document.getElementById('step2-btn').textContent = 'Step 2: Your Interests';
    document.getElementById('step2-btn').className = 'btn btn-outline';
    document.getElementById('step3-btn').textContent = 'Step 3: Your Commitments';
    document.getElementById('step3-btn').className = 'btn btn-outline';

    updateProfileProgress();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
}

// ================================================================
// RESPONSIVE ADJUSTMENTS
// ================================================================

function adjustFeedbackLayout() {
    const layout = document.querySelector('.feedback-layout');
    if (layout) {
        if (window.innerWidth < 900) {
            layout.style.gridTemplateColumns = '1fr';
        } else {
            layout.style.gridTemplateColumns = '1fr 1fr';
        }
    }
}

window.addEventListener('resize', adjustFeedbackLayout);
adjustFeedbackLayout();

function adjustContentLayout() {
    const layout = document.getElementById('content-layout');
    if (layout) {
        if (window.innerWidth < 800) {
            layout.style.gridTemplateColumns = '1fr';
        } else {
            layout.style.gridTemplateColumns = '220px 1fr';
        }
    }
}

window.addEventListener('resize', adjustContentLayout);
adjustContentLayout();